#!/usr/bin/env python

import os
import sys
from codecs import open
from setuptools import setup, find_packages

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, 'README.txt'), 'r', 'utf-8') as handle:
    long_description = handle.read()

with open(os.path.join(here, 'requirements.txt'), 'r', 'utf-8') as handle:
    requires = handle.read()

setup(name='service-platform', 
      version='1.4',
      author='Eric.Zhou', 
      author_email='xiaoxiang.cn@gmail.com', 
      url='https://github.com/zhouxiaoxiang/platform',
      long_description=long_description,
      packages=find_packages(),
      include_package_data=True,
      zip_safe=False,
      install_requires=requires,
      description='Cereson Platform.',
      )
