# PLATFORM README
-----------------

Apply microservices and TDD makes enterprises more productive.

- Install packages.

./setup.py develop

- Show all callable commands.

fab -l

- Run some services.

fab run:user

- Run unit tests.

fab test

- Run system test.

fab sys

- Create platform documents.

fab doc
